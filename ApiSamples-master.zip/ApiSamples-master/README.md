# Octopus/Octoparse Api Samples
These Apis can be used to extract data and operate tasks (advanced features). 

## Samples
- [CSharp](https://github.com/octopus-dev/ApiSamples/tree/master/Code/CSharp)
- [Python](https://github.com/octopus-dev/ApiSamples/tree/master/Code/Python)

# Api Addresses
## For China:
- [DataAPI](http://dataapi.bazhuayu.com/ "DataAPI")
- [AdvancedAPI](http://advancedapi.bazhuayu.com "AdvancedAPI")

## For International:
- [DataAPI](http://dataapi.octoparse.com/ "DataAPI")
- [AdvancedAPI](http://advancedapi.octoparse.com "AdvancedAPI")


Copyright 2017 © Octopus Data Inc.
